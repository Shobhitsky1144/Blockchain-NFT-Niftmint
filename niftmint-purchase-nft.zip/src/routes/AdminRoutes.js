// import React, { createContext, useState, useRef, useEffect } from "react";
// import { Routes, Route } from "react-router-dom";
// // import ResponsiveDrawer from "../ResponsiveDrawer";

// import Sample from "./Sample";
// import SampleOne from "./SampleOne";

// const AdminRoutes = () => {
//   return (
//     <>
//       {/* <ResponsiveDrawer /> */}
//       <Routes>
//         <Route path="/s" element={<Sample />}></Route>
//         <Route path="/ss" element={<SampleOne />}></Route>
//       </Routes>
//     </>
//   );
// };

// export default AdminRoutes;
